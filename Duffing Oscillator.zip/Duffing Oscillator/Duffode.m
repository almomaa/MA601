function xdot = Duffode(t,x)

% Forced Duffing Oscillator

delta = 0.2;
beta  = -1;
alpha = 1;
gamma = 0.3;
omega = 1;


xdot = zeros(size(x));

xdot(1:2:end) =  x(2:2:end);
xdot(2:2:end) =  -delta*x(2:2:end) -beta*x(1:2:end) ...
                 -alpha*x(1:2:end).^3 +gamma*cos(omega*t);
end

